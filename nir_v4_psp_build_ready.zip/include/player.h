#ifndef PLAYER_H
#define PLAYER_H
#include "game.h"

void player_init(Player *p, float x, float z);
void player_update(Player *p, float dt, float mx, float mz);
void player_draw(const Player *p, int is_enemy);

#endif
