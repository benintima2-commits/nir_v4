V4 intentionally uses generated geometry and colors only; no external textures are required.
