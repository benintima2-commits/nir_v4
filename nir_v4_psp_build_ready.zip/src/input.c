#include <pspctrl.h>
#include "input.h"

static SceCtrlData pad;
static unsigned int previous_buttons = 0;
static float triangle_time = 0.0f;

void input_init(void)
{
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    sceCtrlReadBufferPositive(&pad, 1);
    previous_buttons = 0;
    triangle_time = 0.0f;
}

void input_update(InputState *in)
{
    unsigned int b;

    sceCtrlReadBufferPositive(&pad, 1);
    b = pad.Buttons;

    /* Déplacement avec le stick analogique */
    in->x = ((float)pad.Lx - 128.0f) / 128.0f;
    in->z = ((float)pad.Ly - 128.0f) / 128.0f;

    /* X = esquive */
    in->dodge =
        (b & PSP_CTRL_CROSS) &&
        !(previous_buttons & PSP_CTRL_CROSS);

    /* Cercle = attaque lourde */
    in->heavy =
        (b & PSP_CTRL_CIRCLE) &&
        !(previous_buttons & PSP_CTRL_CIRCLE);

    /* Carré = garde */
    in->guard = !!(b & PSP_CTRL_SQUARE);

    /* Triangle = charger le chakra */
    in->chakra = !!(b & PSP_CTRL_TRIANGLE);

    /* Triangle maintenu environ 2 secondes = éveil */
    if (b & PSP_CTRL_TRIANGLE)
        triangle_time += 1.0f / 60.0f;
    else
        triangle_time = 0.0f;

    in->awaken =
        (b & PSP_CTRL_TRIANGLE) &&
        triangle_time >= 2.0f;

    /* L = shuriken */
    in->shuriken =
        (b & PSP_CTRL_LTRIGGER) &&
        !(previous_buttons & PSP_CTRL_LTRIGGER);

    /* R = ciblage */
    in->target =
        (b & PSP_CTRL_RTRIGGER) &&
        !(previous_buttons & PSP_CTRL_RTRIGGER);

    /* START = pause */
    in->start =
        (b & PSP_CTRL_START) &&
        !(previous_buttons & PSP_CTRL_START);

    /* Pas d'attaque légère pour le moment */
    in->light = 0;

    previous_buttons = b;
}
