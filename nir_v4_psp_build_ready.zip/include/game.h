#ifndef GAME_H
#define GAME_H

typedef struct {
    float x, z, rotation;
    float health, energy;
    float attack_timer, dodge_timer, hit_timer;
    int attack, guard, dodge;
} Player;

typedef struct {
    Player player, enemy;
    float camera_x, camera_z;
    int running;
} GameState;

void game_init(GameState *g);
void game_update(GameState *g, float dt);
void game_draw(const GameState *g);

#endif
