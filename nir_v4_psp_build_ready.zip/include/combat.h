#ifndef COMBAT_H
#define COMBAT_H
#include "game.h"

void combat_light(Player *p);
void combat_heavy(Player *p);
void combat_dodge(Player *p);
void combat_update(Player *a, Player *d, float dt);

#endif
