# Ninja Impact Revolution — Arena V4

Original PSP homebrew prototype, designed for testing in PPSSPP.

## Prototype features
- 3D arena without textures
- Original low-poly ninja fighter
- Analog movement
- X = light attack
- O = heavy attack
- Square = dodge
- Triangle = guard
- Automatic enemy fighter
- Health/energy combat logic
- Follow camera centered between fighters

## Build
Requires a working PSPDEV/PSPSDK environment:

    make

Output:

    EBOOT.PBP

Install the EBOOT in a PPSSPP game folder such as `PSP/GAME/NIRV4/`.
