#include <math.h>
#include <pspgu.h>
#include <pspgum.h>
#include "game.h"
#include "input.h"
#include "player.h"
#include "combat.h"

static InputState in;

typedef struct { unsigned int color; float x, y, z; } GVertex;

static void draw_floor(void) {
    GVertex v[6] = {
        {0xFF3B3B3B,-12.0f,0.0f,-12.0f}, {0xFF3B3B3B,12.0f,0.0f,-12.0f}, {0xFF3B3B3B,12.0f,0.0f,12.0f},
        {0xFF3B3B3B,-12.0f,0.0f,-12.0f}, {0xFF3B3B3B,12.0f,0.0f,12.0f}, {0xFF3B3B3B,-12.0f,0.0f,12.0f}
    };
    sceGumDrawArray(GU_TRIANGLES, GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D, 6, 0, v);
}

static void draw_grid(void) {
    GVertex v[96]; int n = 0, i;
    for (i = -10; i <= 10; i++) {
        v[n++] = (GVertex){0xFF606060,(float)i,0.012f,-10.0f};
        v[n++] = (GVertex){0xFF606060,(float)i,0.012f, 10.0f};
        v[n++] = (GVertex){0xFF606060,-10.0f,0.012f,(float)i};
        v[n++] = (GVertex){0xFF606060, 10.0f,0.012f,(float)i};
    }
    sceGumDrawArray(GU_LINES, GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D, n, 0, v);
}

void game_init(GameState *g) {
    player_init(&g->player, -2.5f, 0.0f);
    player_init(&g->enemy,  2.5f, 0.0f);
    g->camera_x = 0.0f; g->camera_z = 0.0f;
    g->running = 1;
    input_init();
}

void game_update(GameState *g, float dt) {
    float dx, dz, len;
    input_update(&in);
    if (in.start) { g->running = 0; return; }

    g->player.guard = in.guard;
    player_update(&g->player, dt, in.x, in.z);

    if (in.light) combat_light(&g->player);
    if (in.heavy) combat_heavy(&g->player);
    if (in.dodge) combat_dodge(&g->player);

    combat_update(&g->player, &g->enemy, dt);

    /* Simple enemy: approaches and attacks automatically. */
    dx = g->player.x - g->enemy.x;
    dz = g->player.z - g->enemy.z;
    len = sqrtf(dx*dx + dz*dz);
    if (len > 2.0f) player_update(&g->enemy, dt, dx, dz);
    else if (len <= 2.0f && g->enemy.attack_timer <= 0.0f && g->enemy.dodge_timer <= 0.0f)
        combat_light(&g->enemy);
    combat_update(&g->enemy, &g->player, dt);

    g->camera_x = (g->player.x + g->enemy.x) * 0.5f;
    g->camera_z = (g->player.z + g->enemy.z) * 0.5f;
}

void game_draw(const GameState *g) {
    ScePspFVector3 eye = {g->camera_x, 9.0f, g->camera_z + 13.0f};
    ScePspFVector3 center = {g->camera_x, 0.8f, g->camera_z};
    ScePspFVector3 up = {0.0f, 1.0f, 0.0f};

    sceGumMatrixMode(GU_PROJECTION);
    sceGumLoadIdentity();
    sceGumPerspective(55.0f, 16.0f/9.0f, 0.5f, 80.0f);

    sceGumMatrixMode(GU_VIEW);
    sceGumLoadIdentity();
    sceGumLookAt(&eye, &center, &up);

    sceGumMatrixMode(GU_MODEL);
    sceGumLoadIdentity();

    draw_floor();
    draw_grid();
    player_draw(&g->player, 0);
    player_draw(&g->enemy, 1);
}
