#include <math.h>
#include "combat.h"

static float distance_between(const Player *a, const Player *b) {
    float dx = a->x - b->x;
    float dz = a->z - b->z;
    return sqrtf(dx * dx + dz * dz);
}

void combat_light(Player *p) {
    if (!p->attack && !p->dodge && !p->guard) {
        p->attack = 1;
        p->attack_timer = 0.28f;
    }
}

void combat_heavy(Player *p) {
    if (!p->attack && !p->dodge && !p->guard && p->energy >= 10.0f) {
        p->attack = 2;
        p->attack_timer = 0.48f;
        p->energy -= 10.0f;
    }
}

void combat_dodge(Player *p) {
    if (!p->attack && !p->dodge && p->energy >= 5.0f) {
        p->dodge = 1;
        p->dodge_timer = 0.22f;
        p->energy -= 5.0f;
    }
}

void combat_update(Player *a, Player *d, float dt) {
    if (a->attack_timer > 0.0f) {
        a->attack_timer -= dt;
        if (a->attack_timer <= 0.0f) {
            float range = (a->attack == 2) ? 2.25f : 1.75f;
            if (distance_between(a, d) <= range && d->dodge_timer <= 0.0f && !d->guard) {
                d->health -= (a->attack == 2) ? 18.0f : 8.0f;
                if (d->health < 0.0f) d->health = 0.0f;
                d->hit_timer = 0.15f;
            }
            a->attack = 0;
        }
    }

    if (a->dodge_timer > 0.0f) {
        a->dodge_timer -= dt;
        if (a->dodge_timer <= 0.0f) a->dodge = 0;
    }
    if (a->hit_timer > 0.0f) a->hit_timer -= dt;

    if (a->energy < 100.0f && !a->attack && !a->dodge)
        a->energy += 8.0f * dt;
    if (a->energy > 100.0f) a->energy = 100.0f;
}
