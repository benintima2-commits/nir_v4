#ifndef INPUT_H
#define INPUT_H

typedef struct {
    float x, z;

    int light;
    int heavy;
    int dodge;
    int guard;

    int chakra;
    int awaken;
    int shuriken;
    int target;

    int start;
} InputState;

void input_init(void);
void input_update(InputState *in);

#endif
