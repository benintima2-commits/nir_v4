#include <math.h>
#include <pspgu.h>
#include <pspgum.h>
#include "player.h"

#define SPEED 4.2f
#define ARENA 11.0f

typedef struct {
    unsigned int color;
    float x, y, z;
} Vertex;

static void draw_box(float x, float y, float z, float sx, float sy, float sz,
                     unsigned int color) {
    Vertex v[36] = {
        {color,-sx, -sy,  sz},{color, sx, -sy,  sz},{color, sx, sy, sz},
        {color,-sx, -sy,  sz},{color, sx, sy,  sz},{color,-sx, sy, sz},
        {color, sx, -sy,-sz},{color,-sx, -sy,-sz},{color,-sx, sy,-sz},
        {color, sx, -sy,-sz},{color,-sx, sy,-sz},{color, sx, sy,-sz},
        {color,-sx, -sy,-sz},{color,-sx, -sy, sz},{color,-sx, sy, sz},
        {color,-sx, -sy,-sz},{color,-sx, sy, sz},{color,-sx, sy,-sz},
        {color, sx, -sy, sz},{color, sx, -sy,-sz},{color, sx, sy,-sz},
        {color, sx, -sy, sz},{color, sx, sy,-sz},{color, sx, sy,sz},
        {color,-sx, sy, sz},{color, sx, sy, sz},{color, sx, sy,-sz},
        {color,-sx, sy, sz},{color, sx, sy,-sz},{color,-sx, sy,-sz},
        {color,-sx,-sy,-sz},{color, sx,-sy,-sz},{color, sx,-sy, sz},
        {color,-sx,-sy,-sz},{color, sx,-sy, sz},{color,-sx,-sy, sz}
    };

    sceGumPushMatrix();
    {
        ScePspFVector3 p = {x, y, z};
        sceGumTranslate(&p);
    }
    sceGumDrawArray(GU_TRIANGLES,
        GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_3D,
        36, 0, v);
    sceGumPopMatrix();
}

void player_init(Player *p, float x, float z) {
    p->x = x; p->z = z; p->rotation = 0.0f;
    p->health = 100.0f; p->energy = 100.0f;
    p->attack_timer = 0.0f; p->dodge_timer = 0.0f; p->hit_timer = 0.0f;
    p->attack = 0; p->guard = 0; p->dodge = 0;
}

void player_update(Player *p, float dt, float mx, float mz) {
    float len = sqrtf(mx * mx + mz * mz);
    if (p->attack_timer > 0.0f || p->dodge_timer > 0.0f) return;

    if (len > 0.15f) {
        mx /= len; mz /= len;
        p->x += mx * SPEED * dt;
        p->z += mz * SPEED * dt;
        p->rotation = atan2f(mx, mz);
    }

    if (p->x < -ARENA) p->x = -ARENA;
    if (p->x >  ARENA) p->x =  ARENA;
    if (p->z < -ARENA) p->z = -ARENA;
    if (p->z >  ARENA) p->z =  ARENA;
}

void player_draw(const Player *p, int is_enemy) {
    unsigned int body = is_enemy ? 0xFFCC5533 : 0xFF3366CC;
    unsigned int dark = is_enemy ? 0xFF772211 : 0xFF162F66;
    unsigned int skin = 0xFFE0A080;
    float arm = (p->attack == 1 || p->attack == 2) ? 0.95f : 0.45f;

    sceGumPushMatrix();
    {
        ScePspFVector3 pos = {p->x, 0.0f, p->z};
        sceGumTranslate(&pos);
        sceGumRotateY(p->rotation);
    }

    /* Simple original low-poly ninja: feet, legs, torso, head and arms. */
    draw_box(0.0f, 0.35f, 0.0f, 0.34f, 0.35f, 0.28f, dark);
    draw_box(-0.22f, 0.95f, 0.0f, 0.16f, 0.45f, 0.20f, body);
    draw_box( 0.22f, 0.95f, 0.0f, 0.16f, 0.45f, 0.20f, body);
    draw_box(0.0f, 1.65f, 0.0f, 0.55f, 0.45f, 0.32f, body);
    draw_box(0.0f, 2.35f, 0.0f, 0.38f, 0.32f, 0.30f, skin);
    draw_box(-0.72f, 1.60f, arm * 0.15f, 0.16f, 0.18f, 0.18f, body);
    draw_box( 0.72f, 1.60f, arm * 0.35f, 0.16f, 0.18f, 0.18f, body);

    sceGumPopMatrix();
}
